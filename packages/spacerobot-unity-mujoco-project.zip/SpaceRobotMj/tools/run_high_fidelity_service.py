import argparse
import csv
import math
import time
from pathlib import Path

import mujoco
import numpy as np

from build_high_fidelity_model import (
    FOREARM_LENGTH,
    INITIAL_ANCHORS,
    LEGS,
    OUTPUT as XML_PATH,
    UPPER_LENGTH,
    build as build_model,
)


HERE = Path(__file__).resolve().parent
METRICS_PATH = HERE / "high_fidelity_service_metrics.csv"

ORBIT_ALTITUDE = 420_000.0
EARTH_MU = 3.986004418e14
EARTH_RADIUS = 6_371_000.0
ORBIT_RADIUS = EARTH_RADIUS + ORBIT_ALTITUDE
ORBIT_RATE = math.sqrt(EARTH_MU / ORBIT_RADIUS**3)
ORBIT_SPEED = math.sqrt(EARTH_MU / ORBIT_RADIUS)
DISPLAY_EARTH_CENTER = np.array([-10.0, 7.0, -5.0])
DISPLAY_ORBIT_RATE = 0.002

LEGS_ORDER = ("FL", "RR", "FR", "RL")
SETTLE_TIME = 3.0
STEP_PERIOD = 2.40
STRIDE = 0.50
SWING_CLEARANCE = 0.22
LOCOMOTION_STEPS = 40
PALM_OFFSET = np.array([0.0, 0.0, 0.090])
CAP_TARGET = np.array([3.05, -1.00, 0.86])
LOG_INTERVAL = 10


def smoothstep(x):
    x = np.clip(x, 0.0, 1.0)
    return x * x * (3.0 - 2.0 * x)


def rot_z(angle):
    c, s = math.cos(angle), math.sin(angle)
    return np.array(((c, -s, 0.0), (s, c, 0.0), (0.0, 0.0, 1.0)))


def rot_y(angle):
    c, s = math.cos(angle), math.sin(angle)
    return np.array(((c, 0.0, s), (0.0, 1.0, 0.0), (-s, 0.0, c)))


def zyx_angles(matrix):
    pitch = math.asin(float(np.clip(-matrix[2, 0], -1.0, 1.0)))
    if abs(math.cos(pitch)) > 1e-7:
        yaw = math.atan2(matrix[1, 0], matrix[0, 0])
        roll = math.atan2(matrix[2, 1], matrix[2, 2])
    else:
        yaw = math.atan2(-matrix[0, 1], matrix[1, 1])
        roll = 0.0
    return yaw, pitch, roll


def joint_qpos_address(model, name):
    return model.jnt_qposadr[model.joint(name).id]


def joint_dof_address(model, name):
    return model.jnt_dofadr[model.joint(name).id]


def set_joint_qpos(model, data, name, value):
    data.qpos[joint_qpos_address(model, name)] = value


def joint_value(model, data, name):
    return float(data.qpos[joint_qpos_address(model, name)])


def command_joint(model, data, name, value):
    data.ctrl[model.actuator(f"act_{name}").id] = value


def solve_limb_ik(leg, relative, desired_palm_rotation):
    shoulder_pos, heading = LEGS[leg]
    upper_length = UPPER_LENGTH
    forearm_length = FOREARM_LENGTH
    local = rot_z(-heading) @ (np.asarray(relative) - np.asarray(shoulder_pos))
    yaw = math.atan2(local[1], local[0])
    radial = math.hypot(local[0], local[1])
    distance2 = radial * radial + local[2] * local[2]
    cos_elbow = np.clip(
        (distance2 - upper_length**2 - forearm_length**2)
        / (2.0 * upper_length * forearm_length),
        -0.999,
        0.999,
    )
    elbow = math.acos(float(cos_elbow))
    pitch = math.atan2(-local[2], radial) - math.atan2(
        forearm_length * math.sin(elbow),
        upper_length + forearm_length * math.cos(elbow),
    )

    forearm_rotation = rot_z(heading + yaw) @ rot_y(pitch + elbow)
    wrist_yaw, wrist_pitch, wrist_roll = zyx_angles(
        forearm_rotation.T @ desired_palm_rotation
    )
    return {
        f"{leg}_yaw": yaw,
        f"{leg}_pitch": pitch,
        f"{leg}_elbow": elbow,
        f"{leg}_wrist_yaw": wrist_yaw,
        f"{leg}_wrist_pitch": wrist_pitch,
        f"{leg}_wrist_roll": wrist_roll,
    }


def inverse_kinematics(leg, base_position, grasp_target, palm_twist=0.0):
    palm_target = np.asarray(grasp_target) + PALM_OFFSET
    relative = palm_target - np.asarray(base_position)
    return solve_limb_ik(leg, relative, rot_z(palm_twist))


def actual_pose_inverse_kinematics(model, data, leg, grasp_target, palm_twist=0.0):
    station_id = model.body("station").id
    robot_id = model.body("robot").id
    station_rotation = data.xmat[station_id].reshape(3, 3)
    robot_rotation = data.xmat[robot_id].reshape(3, 3)
    target_world = data.xpos[station_id] + station_rotation @ (np.asarray(grasp_target) + PALM_OFFSET)
    relative_robot = robot_rotation.T @ (target_world - data.xpos[robot_id])
    desired_palm_rotation = robot_rotation.T @ station_rotation @ rot_z(palm_twist)
    return solve_limb_ik(leg, relative_robot, desired_palm_rotation)


def finger_targets(leg, closure):
    closure = float(np.clip(closure, 0.0, 1.0))
    result = {}
    for index in range(1, 5):
        side = 1.0 if index <= 2 else -1.0
        open_prox = side * 0.72
        closed_prox = -side * 0.36
        closed_dist = -side * 0.68
        result[f"{leg}_finger{index}_prox"] = (1.0 - closure) * open_prox + closure * closed_prox
        result[f"{leg}_finger{index}_dist"] = closure * closed_dist
    return result


def apply_targets(model, data, base_position, grasp_targets, closures, palm_twists, actual_frame=False):
    for leg in LEGS:
        if actual_frame:
            targets = actual_pose_inverse_kinematics(
                model, data, leg, grasp_targets[leg], palm_twists.get(leg, 0.0)
            )
        else:
            targets = inverse_kinematics(
                leg, base_position, grasp_targets[leg], palm_twists.get(leg, 0.0)
            )
        targets.update(finger_targets(leg, closures[leg]))
        for joint, target in targets.items():
            command_joint(model, data, joint, target)


def initialize_joint_state(model, data, base_position, anchors):
    for leg in LEGS:
        targets = inverse_kinematics(leg, base_position, anchors[leg])
        targets.update(finger_targets(leg, 1.0))
        for joint, target in targets.items():
            set_joint_qpos(model, data, joint, target)
            command_joint(model, data, joint, target)


def geom_name(model, geom_id):
    return mujoco.mj_id2name(model, mujoco.mjtObj.mjOBJ_GEOM, geom_id) or ""


def contact_measurements(model, data):
    rail_fingers = {leg: set() for leg in LEGS}
    cap_fingers = {leg: set() for leg in LEGS}
    grip_forces = {leg: 0.0 for leg in LEGS}
    unwanted_contacts = 0
    unwanted_pairs = set()
    maximum_penetration = 0.0
    cap_contact_force = 0.0
    for contact_index in range(data.ncon):
        contact = data.contact[contact_index]
        name1 = geom_name(model, contact.geom1)
        name2 = geom_name(model, contact.geom2)
        names = (name1, name2)
        force6 = np.zeros(6)
        mujoco.mj_contactForce(model, data, contact_index, force6)
        force_norm = float(np.linalg.norm(force6[:3]))
        maximum_penetration = max(maximum_penetration, max(0.0, -float(contact.dist)))

        finger_name = next((name for name in names if "_finger" in name), None)
        other_name = name2 if finger_name == name1 else name1
        if finger_name:
            leg = finger_name[:2]
            marker = finger_name.split("_finger", 1)[1]
            finger_index = int(marker.split("_", 1)[0])
            grip_forces[leg] += force_norm
            if other_name.startswith("rail_y"):
                rail_fingers[leg].add(finger_index)
            elif other_name.startswith("service_cap") or other_name.startswith("cap_rib"):
                cap_fingers[leg].add(finger_index)
                cap_contact_force += force_norm
            else:
                unwanted_contacts += 1
                unwanted_pairs.add(f"{name1}|{name2}")
        else:
            robot_collision = any(
                token in name
                for name in names
                for token in ("robot_torso", "robot_top", "upper_geom", "forearm_geom", "palm_geom", "shoulder_shell", "elbow_shell")
            )
            station_collision = any(
                name.startswith(("rail_", "top_rung", "bottom_rung", "side_diag", "service_", "central_", "lab_", "node_", "panel_", "radiator_"))
                for name in names
            )
            if robot_collision and station_collision and contact.dist < -0.001:
                unwanted_contacts += 1
                unwanted_pairs.add(f"{name1}|{name2}")
    return {
        "rail_fingers": rail_fingers,
        "cap_fingers": cap_fingers,
        "grip_forces": grip_forces,
        "unwanted_contacts": unwanted_contacts,
        "unwanted_pairs": sorted(unwanted_pairs),
        "maximum_penetration": maximum_penetration,
        "cap_contact_force": cap_contact_force,
    }


def site_error(model, data, site1, site2):
    p1 = data.site_xpos[model.site(site1).id]
    p2 = data.site_xpos[model.site(site2).id]
    return float(np.linalg.norm(p1 - p2))


def apply_cartesian_joint_control(model, data, leg, target_station_local, force_limit=120.0):
    station_id = model.body("station").id
    station_rotation = data.xmat[station_id].reshape(3, 3)
    target_world = data.xpos[station_id] + station_rotation @ np.asarray(target_station_local)
    site_id = model.site(f"{leg}_grasp_site").id
    jacobian = np.zeros((3, model.nv))
    mujoco.mj_jacSite(model, data, jacobian, None, site_id)
    velocity = jacobian @ data.qvel
    position_error = target_world - data.site_xpos[site_id]
    task_force = 420.0 * position_error - 28.0 * velocity
    force_norm = np.linalg.norm(task_force)
    if force_norm > force_limit:
        task_force *= force_limit / force_norm
    joints = (
        (f"{leg}_yaw", 35.0),
        (f"{leg}_pitch", 55.0),
        (f"{leg}_elbow", 45.0),
        (f"{leg}_wrist_yaw", 10.0),
        (f"{leg}_wrist_pitch", 10.0),
        (f"{leg}_wrist_roll", 12.0),
    )
    for joint, torque_limit in joints:
        dof = joint_dof_address(model, joint)
        torque = float(jacobian[:, dof] @ task_force)
        data.qfrc_applied[dof] += np.clip(torque, -torque_limit, torque_limit)


def relative_attitude_error(model, data):
    station_rotation = data.xmat[model.body("station").id].reshape(3, 3)
    robot_rotation = data.xmat[model.body("robot").id].reshape(3, 3)
    relative_rotation = station_rotation.T @ robot_rotation
    cosine = np.clip((np.trace(relative_rotation) - 1.0) * 0.5, -1.0, 1.0)
    return float(math.acos(cosine))


def station_attitude_error(model, data):
    station_rotation = data.xmat[model.body("station").id].reshape(3, 3)
    cosine = np.clip((np.trace(station_rotation) - 1.0) * 0.5, -1.0, 1.0)
    return float(math.acos(cosine))


def display_orbit_velocity(reference_position):
    radial = np.asarray(reference_position) - DISPLAY_EARTH_CENTER
    return DISPLAY_ORBIT_RATE * np.array([-radial[1], radial[0], 0.0])


def apply_earth_centered_display_orbit(model, data):
    for body_name in ("station", "robot"):
        body_id = model.body(body_name).id
        radial = data.xpos[body_id] - DISPLAY_EARTH_CENTER
        radial[2] = 0.0
        acceleration = -(DISPLAY_ORBIT_RATE**2) * radial
        data.xfrc_applied[body_id, :3] += model.body_subtreemass[body_id] * acceleration


def apply_station_attitude_hold(model, data):
    station_id = model.body("station").id
    station_rotation = data.xmat[station_id].reshape(3, 3)
    attitude_error = 0.5 * np.array([
        station_rotation[2, 1] - station_rotation[1, 2],
        station_rotation[0, 2] - station_rotation[2, 0],
        station_rotation[1, 0] - station_rotation[0, 1],
    ])
    station_dof = model.jnt_dofadr[model.joint("station_free").id]
    angular_velocity = data.qvel[station_dof + 3:station_dof + 6]
    torque = -1200.0 * attitude_error - 300.0 * angular_velocity
    torque_norm = np.linalg.norm(torque)
    if torque_norm > 400.0:
        torque *= 400.0 / torque_norm
    data.xfrc_applied[station_id, 3:] += torque


def apply_whole_body_stabilization(model, data, target_station_local):
    station_id = model.body("station").id
    robot_id = model.body("robot").id
    station_rotation = data.xmat[station_id].reshape(3, 3)
    robot_rotation = data.xmat[robot_id].reshape(3, 3)
    target_world = data.xpos[station_id] + station_rotation @ np.asarray(target_station_local)

    station_dof = model.jnt_dofadr[model.joint("station_free").id]
    robot_dof = model.jnt_dofadr[model.joint("robot_free").id]
    relative_linear_velocity = (
        data.qvel[robot_dof:robot_dof + 3] - data.qvel[station_dof:station_dof + 3]
    )
    force = 85.0 * (target_world - data.xpos[robot_id]) - 30.0 * relative_linear_velocity
    force_norm = np.linalg.norm(force)
    if force_norm > 65.0:
        force *= 65.0 / force_norm

    relative_rotation = station_rotation.T @ robot_rotation
    attitude_error_station = 0.5 * np.array([
        relative_rotation[2, 1] - relative_rotation[1, 2],
        relative_rotation[0, 2] - relative_rotation[2, 0],
        relative_rotation[1, 0] - relative_rotation[0, 1],
    ])
    attitude_error_world = station_rotation @ attitude_error_station
    relative_angular_velocity = (
        data.qvel[robot_dof + 3:robot_dof + 6]
        - data.qvel[station_dof + 3:station_dof + 6]
    )
    torque = -180.0 * attitude_error_world - 50.0 * relative_angular_velocity
    torque_norm = np.linalg.norm(torque)
    if torque_norm > 90.0:
        torque *= 90.0 / torque_norm

    data.xfrc_applied[robot_id, :3] += force
    data.xfrc_applied[robot_id, 3:] += torque
    data.xfrc_applied[station_id, :3] -= force
    data.xfrc_applied[station_id, 3:] -= torque


class MissionController:
    def __init__(self, model, data):
        self.model = model
        self.data = data
        self.anchors = {leg: np.array(point, dtype=float) for leg, point in INITIAL_ANCHORS.items()}
        self.step_index = -1
        self.step_start = SETTLE_TIME
        self.swing_leg = None
        self.swing_start = None
        self.swing_end = None
        self.swing_target_moved = False
        self.manipulation_start = None
        self.stage = "initial-grasp-settle"
        self.regrasp_failures = 0
        self.max_latch_error = 0.0
        self.cap_grasp_verified = False
        self.eq_rail = {leg: model.equality(f"rail_latch_{leg}").id for leg in LEGS}
        self.eq_cap = model.equality("cap_latch_FR").id
        self.target_sites = {leg: model.site(f"rail_target_{leg}").id for leg in LEGS}
        self.initial_robot_com = None
        for leg in LEGS:
            model.site_pos[self.target_sites[leg]] = self.anchors[leg]

    def set_rail_latch(self, leg, active):
        self.data.eq_active[self.eq_rail[leg]] = int(active)

    def rail_latched(self, leg):
        return bool(self.data.eq_active[self.eq_rail[leg]])

    def set_cap_latch(self, active):
        self.data.eq_active[self.eq_cap] = int(active)

    def contacted_rail_point(self, leg):
        station_id = self.model.body("station").id
        rotation = self.data.xmat[station_id].reshape(3, 3)
        station_position = self.data.xpos[station_id]
        grasp_world = self.data.site_xpos[self.model.site(f"{leg}_grasp_site").id]
        local = rotation.T @ (grasp_world - station_position)
        rail_center = np.array([local[0], self.swing_end[1], 0.58])
        return local, rail_center


    def start_next_step(self, now):
        self.step_index += 1
        if self.step_index >= LOCOMOTION_STEPS:
            self.swing_leg = None
            self.manipulation_start = now + 1.5
            self.stage = "service-settle"
            return
        self.swing_leg = LEGS_ORDER[self.step_index % len(LEGS_ORDER)]
        self.swing_start = self.anchors[self.swing_leg].copy()
        self.swing_end = self.swing_start + np.array([STRIDE, 0.0, 0.0])
        self.swing_target_moved = False
        self.step_start = now

    def locomotion_targets(self, now, contacts):
        if self.step_index < 0:
            self.start_next_step(now)
        phase = min(1.0, max(0.0, (now - self.step_start) / STEP_PERIOD))
        leg = self.swing_leg
        targets = {name: point.copy() for name, point in self.anchors.items()}
        closures = {name: 1.0 for name in LEGS}
        twists = {name: 0.0 for name in LEGS}

        if phase < 0.18:
            closures[leg] = 1.0 - smoothstep(phase / 0.18)
            self.stage = f"open-{leg}"
        else:
            self.set_rail_latch(leg, False)
            if not self.swing_target_moved:
                self.model.site_pos[self.target_sites[leg]] = self.swing_end
                self.swing_target_moved = True
            if phase < 0.78:
                swing = smoothstep((phase - 0.18) / 0.60)
                targets[leg] = (1.0 - swing) * self.swing_start + swing * self.swing_end
                targets[leg][2] += SWING_CLEARANCE * math.sin(math.pi * swing)
                closures[leg] = 0.0
                self.stage = f"swing-{leg}"
            elif phase < 0.90:
                targets[leg] = self.swing_end.copy()
                closures[leg] = 0.0
                self.stage = f"approach-{leg}"
            else:
                targets[leg] = self.swing_end.copy()
                closures[leg] = smoothstep((phase - 0.90) / 0.10)
                self.stage = f"wrap-{leg}"
                if len(contacts["rail_fingers"][leg]) >= 2:
                    contact_pose, rail_center = self.contacted_rail_point(leg)
                    if rail_center[0] - self.swing_start[0] >= 0.30:
                        self.swing_end = rail_center
                        self.model.site_pos[self.target_sites[leg]] = contact_pose
                        self.set_rail_latch(leg, True)

        target_mean = sum(targets.values()) / 4.0
        base_target = target_mean + np.array([0.0, 0.0, 0.60])
        if phase >= 1.0:
            if self.rail_latched(leg):
                self.anchors[leg] = self.swing_end.copy()
                self.start_next_step(now)
            else:
                self.regrasp_failures += 1
                self.stage = f"contact-wait-{leg}"
        return base_target, targets, closures, twists

    def manipulation_targets(self, now, contacts):
        elapsed = max(0.0, now - self.manipulation_start)
        targets = {name: point.copy() for name, point in self.anchors.items()}
        closures = {name: 1.0 for name in LEGS}
        twists = {name: 0.0 for name in LEGS}
        cap_start = self.anchors["FR"].copy()
        base_target = sum(self.anchors.values()) / 4.0 + np.array([0.0, 0.0, 0.60])

        if elapsed < 2.0:
            closures["FR"] = 1.0 - smoothstep(elapsed / 2.0)
            self.stage = "release-FR-for-service"
        elif elapsed < 4.0:
            self.set_rail_latch("FR", False)
            lift = smoothstep((elapsed - 2.0) / 2.0)
            targets["FR"] = cap_start + np.array([0.0, 0.0, 0.30 * lift])
            closures["FR"] = 0.0
            self.stage = "retract-FR-above-rail"
        elif elapsed < 9.0:
            self.set_rail_latch("FR", False)
            move = smoothstep((elapsed - 4.0) / 5.0)
            high_start = cap_start + np.array([0.0, 0.0, 0.30])
            high_cap = CAP_TARGET + np.array([0.0, 0.0, 0.30])
            targets["FR"] = (1.0 - move) * high_start + move * high_cap
            closures["FR"] = 0.0
            self.stage = "transfer-FR-above-cap"
        elif elapsed < 11.0:
            self.set_rail_latch("FR", False)
            descend = smoothstep((elapsed - 9.0) / 2.0)
            targets["FR"] = CAP_TARGET + np.array([0.0, 0.0, 0.30 * (1.0 - descend)])
            closures["FR"] = 0.0
            self.stage = "descend-FR-to-cap"
        elif elapsed < 13.5:
            self.set_rail_latch("FR", False)
            targets["FR"] = CAP_TARGET.copy()
            closures["FR"] = 0.86 * smoothstep((elapsed - 11.0) / 2.5)
            self.stage = "wrap-fingers-around-cap"
            error = site_error(self.model, self.data, "FR_grasp_site", "cap_target")
            if len(contacts["cap_fingers"]["FR"]) >= 2 and error < 0.020:
                self.cap_grasp_verified = True
        else:
            targets["FR"] = CAP_TARGET.copy()
            closures["FR"] = 0.86
            if not self.cap_grasp_verified:
                error = site_error(self.model, self.data, "FR_grasp_site", "cap_target")
                if len(contacts["cap_fingers"]["FR"]) >= 2 and error < 0.020:
                    self.cap_grasp_verified = True
                self.stage = "cap-contact-wait"
            else:
                twist = smoothstep((elapsed - 13.5) / 10.0) * 0.95
                twists["FR"] = twist
                self.stage = "physical-cap-twist" if twist < 0.94 else "cap-task-complete"

        return base_target, targets, closures, twists

    def update(self, now, contacts):
        self.data.qfrc_applied[:] = 0.0
        self.data.xfrc_applied[:] = 0.0
        if now < SETTLE_TIME:
            targets = {name: point.copy() for name, point in self.anchors.items()}
            closures = {name: 1.0 for name in LEGS}
            twists = {name: 0.0 for name in LEGS}
            base_target = sum(targets.values()) / 4.0 + np.array([0.0, 0.0, 0.60])
        elif self.manipulation_start is None:
            base_target, targets, closures, twists = self.locomotion_targets(now, contacts)
        elif now < self.manipulation_start:
            targets = {name: point.copy() for name, point in self.anchors.items()}
            closures = {name: 1.0 for name in LEGS}
            twists = {name: 0.0 for name in LEGS}
            base_target = sum(targets.values()) / 4.0 + np.array([0.0, 0.0, 0.60])
        else:
            base_target, targets, closures, twists = self.manipulation_targets(now, contacts)
        actual_frame = self.manipulation_start is not None and now >= self.manipulation_start
        apply_targets(
            self.model,
            self.data,
            base_target,
            targets,
            closures,
            twists,
            actual_frame=actual_frame,
        )
        apply_whole_body_stabilization(self.model, self.data, base_target)
        apply_earth_centered_display_orbit(self.model, self.data)
        apply_station_attitude_hold(self.model, self.data)
        if actual_frame:
            for leg in LEGS:
                if leg != "FR" and self.rail_latched(leg):
                    for suffix in ("yaw", "pitch", "elbow", "wrist_yaw", "wrist_pitch", "wrist_roll"):
                        joint = f"{leg}_{suffix}"
                        command_joint(self.model, self.data, joint, joint_value(self.model, self.data, joint))
        for leg in LEGS:
            cap_attached = leg == "FR" and bool(self.data.eq_active[self.eq_cap])
            if not self.rail_latched(leg) and not cap_attached:
                force_limit = 35.0 if leg == "FR" and self.cap_grasp_verified else 120.0
                apply_cartesian_joint_control(
                    self.model, self.data, leg, targets[leg], force_limit=force_limit
                )


def initialize_model(model, data):
    station_joint = model.joint("station_free").id
    robot_joint = model.joint("robot_free").id
    station_qvel = model.jnt_dofadr[station_joint]
    robot_qvel = model.jnt_dofadr[robot_joint]
    initial_orbit_velocity = display_orbit_velocity(np.zeros(3))
    data.qvel[station_qvel:station_qvel + 3] = initial_orbit_velocity
    data.qvel[robot_qvel:robot_qvel + 3] = initial_orbit_velocity
    data.qvel[station_qvel + 3:station_qvel + 6] = 0.0
    data.qvel[robot_qvel + 3:robot_qvel + 6] = 0.0
    base = np.array([-2.70, 0.0, 1.18])
    initialize_joint_state(model, data, base, INITIAL_ANCHORS)
    for leg in LEGS:
        data.eq_active[model.equality(f"rail_latch_{leg}").id] = 1
    data.eq_active[model.equality("cap_latch_FR").id] = 0
    mujoco.mj_forward(model, data)
    closures = {leg: 1.0 for leg in LEGS}
    twists = {leg: 0.0 for leg in LEGS}
    anchors = {leg: np.array(point, dtype=float) for leg, point in INITIAL_ANCHORS.items()}
    for _ in range(1500):
        apply_targets(model, data, base, anchors, closures, twists)
        mujoco.mj_step(model, data)
    data.time = 0.0


def configure_service_regression(model, data, controller):
    final_anchors = {
        leg: np.array(point, dtype=float) + np.array([5.0, 0.0, 0.0])
        for leg, point in INITIAL_ANCHORS.items()
    }
    station_joint = model.joint("station_free").id
    robot_joint = model.joint("robot_free").id
    station_qpos = model.jnt_qposadr[station_joint]
    robot_qpos = model.jnt_qposadr[robot_joint]
    data.qpos[station_qpos:station_qpos + 7] = np.array([0, 0, 0, 1, 0, 0, 0])
    data.qpos[robot_qpos:robot_qpos + 7] = np.array([2.30, 0, 1.18, 1, 0, 0, 0])
    data.qvel[:] = 0.0
    initial_orbit_velocity = display_orbit_velocity(np.zeros(3))
    data.qvel[model.jnt_dofadr[station_joint]:model.jnt_dofadr[station_joint] + 3] = initial_orbit_velocity
    data.qvel[model.jnt_dofadr[robot_joint]:model.jnt_dofadr[robot_joint] + 3] = initial_orbit_velocity
    data.qvel[model.jnt_dofadr[station_joint] + 3:model.jnt_dofadr[station_joint] + 6] = 0.0
    data.qvel[model.jnt_dofadr[robot_joint] + 3:model.jnt_dofadr[robot_joint] + 6] = 0.0
    set_joint_qpos(model, data, "cap_hinge", 0.0)
    initialize_joint_state(model, data, np.array([2.30, 0.0, 1.18]), final_anchors)
    controller.anchors = {leg: point.copy() for leg, point in final_anchors.items()}
    controller.step_index = LOCOMOTION_STEPS
    controller.swing_leg = None
    controller.manipulation_start = 1.0
    controller.stage = "service-regression-settle"
    for leg in LEGS:
        model.site_pos[controller.target_sites[leg]] = final_anchors[leg]
        controller.set_rail_latch(leg, True)
    controller.set_cap_latch(False)
    mujoco.mj_forward(model, data)
    closures = {leg: 1.0 for leg in LEGS}
    twists = {leg: 0.0 for leg in LEGS}
    for _ in range(1000):
        apply_targets(model, data, np.array([2.30, 0.0, 1.18]), final_anchors, closures, twists)
        mujoco.mj_step(model, data)
    data.time = 0.0


def header():
    fields = [
        "time_s", "mission_stage", "swing_leg", "active_rail_latches", "cap_latch_active", "cap_grasp_verified",
        "robot_x_m", "robot_y_m", "robot_z_m", "station_x_m", "station_y_m", "station_z_m",
        "robot_station_relative_speed_mps", "station_local_speed_mps", "station_eci_speed_mps",
        "relative_attitude_error_rad", "relative_angular_speed_radps", "station_attitude_error_rad",
        "cap_angle_rad", "cap_rate_radps", "cap_contact_force_N", "unwanted_contact_count", "unwanted_contact_pairs",
        "maximum_penetration_m", "maximum_latch_error_m", "regrasp_wait_steps",
    ]
    for leg in LEGS:
        fields.extend((f"{leg}_rail_finger_contacts", f"{leg}_cap_finger_contacts", f"{leg}_grip_force_N", f"{leg}_rail_latch_error_m"))
    for leg in LEGS:
        fields.extend((f"{leg}_shoulder_torque_Nm", f"{leg}_elbow_torque_Nm", f"{leg}_wrist_torque_Nm"))
    return fields


def row(model, data, controller, contacts):
    robot_id = model.body("robot").id
    station_id = model.body("station").id
    robot_pos = data.xpos[robot_id]
    station_pos = data.xpos[station_id]
    robot_joint = model.joint("robot_free").id
    station_joint = model.joint("station_free").id
    robot_vel = data.qvel[model.jnt_dofadr[robot_joint]: model.jnt_dofadr[robot_joint] + 3]
    station_vel = data.qvel[model.jnt_dofadr[station_joint]: model.jnt_dofadr[station_joint] + 3]
    robot_omega = data.qvel[model.jnt_dofadr[robot_joint] + 3: model.jnt_dofadr[robot_joint] + 6]
    station_omega = data.qvel[model.jnt_dofadr[station_joint] + 3: model.jnt_dofadr[station_joint] + 6]
    latch_errors = {
        leg: site_error(model, data, f"{leg}_grasp_site", f"rail_target_{leg}")
        for leg in LEGS
    }
    active_errors = [latch_errors[leg] for leg in LEGS if controller.rail_latched(leg)]
    if bool(data.eq_active[controller.eq_cap]):
        active_errors.append(site_error(model, data, "FR_grasp_site", "cap_target"))
    controller.max_latch_error = max(controller.max_latch_error, max(active_errors, default=0.0))
    values = [
        data.time,
        controller.stage,
        controller.swing_leg or "none",
        sum(controller.rail_latched(leg) for leg in LEGS),
        int(bool(data.eq_active[controller.eq_cap])),
        int(controller.cap_grasp_verified),
        *robot_pos,
        *station_pos,
        np.linalg.norm(robot_vel - station_vel),
        np.linalg.norm(station_vel),
        ORBIT_SPEED + station_vel[0],
        relative_attitude_error(model, data),
        np.linalg.norm(robot_omega - station_omega),
        station_attitude_error(model, data),
        joint_value(model, data, "cap_hinge"),
        data.qvel[joint_dof_address(model, "cap_hinge")],
        contacts["cap_contact_force"],
        contacts["unwanted_contacts"],
        ";".join(contacts["unwanted_pairs"]),
        contacts["maximum_penetration"],
        controller.max_latch_error,
        controller.regrasp_failures,
    ]
    for leg in LEGS:
        values.extend((
            len(contacts["rail_fingers"][leg]),
            len(contacts["cap_fingers"][leg]),
            contacts["grip_forces"][leg],
            latch_errors[leg],
        ))
    for leg in LEGS:
        shoulder = abs(data.qfrc_actuator[joint_dof_address(model, f"{leg}_pitch")])
        elbow = abs(data.qfrc_actuator[joint_dof_address(model, f"{leg}_elbow")])
        wrist = math.sqrt(sum(
            data.qfrc_actuator[joint_dof_address(model, f"{leg}_wrist_{axis}")] ** 2
            for axis in ("yaw", "pitch", "roll")
        ))
        values.extend((shoulder, elbow, wrist))
    return values


def run(duration, headless, service_test=False):
    build_model()
    model = mujoco.MjModel.from_xml_path(str(XML_PATH))
    data = mujoco.MjData(model)
    initialize_model(model, data)
    controller = MissionController(model, data)
    if service_test:
        configure_service_regression(model, data, controller)
    initial_contacts = contact_measurements(model, data)
    print(
        "Initial physical finger contacts: "
        + ", ".join(f"{leg}={len(initial_contacts['rail_fingers'][leg])}" for leg in LEGS)
    )

    with METRICS_PATH.open("w", newline="") as metrics_file:
        writer = csv.writer(metrics_file)
        writer.writerow(header())
        if not headless:
            import mujoco.viewer

        viewer_context = mujoco.viewer.launch_passive(model, data) if not headless else NullContext()
        with viewer_context as viewer:
            if not headless:
                viewer.cam.distance = 10.5
                viewer.cam.azimuth = 132
                viewer.cam.elevation = -20
                viewer.cam.lookat[:] = np.array([1.3, 0.4, 0.35])
            step_count = 0
            while data.time < duration:
                contacts = contact_measurements(model, data)
                controller.update(data.time, contacts)
                mujoco.mj_step(model, data)
                if step_count % LOG_INTERVAL == 0:
                    post_contacts = contact_measurements(model, data)
                    writer.writerow(row(model, data, controller, post_contacts))
                if not headless:
                    viewer.sync()
                    time.sleep(model.opt.timestep)
                step_count += 1

    final_cap = joint_value(model, data, "cap_hinge")
    print(f"Saved {METRICS_PATH}")
    print(f"Final cap angle: {final_cap:.5f} rad")
    print(f"Maximum active-latch error: {controller.max_latch_error:.6f} m")
    print(f"Regrasp wait steps: {controller.regrasp_failures}")


class NullContext:
    def __enter__(self):
        return None

    def __exit__(self, *_):
        return False


def main():
    parser = argparse.ArgumentParser(description="Articulated space robot truss locomotion and cap service mission")
    parser.add_argument("--duration", type=float, default=150.0)
    parser.add_argument("--headless", action="store_true")
    parser.add_argument("--service-test", action="store_true")
    args = parser.parse_args()
    run(args.duration, args.headless, args.service_test)


if __name__ == "__main__":
    main()
