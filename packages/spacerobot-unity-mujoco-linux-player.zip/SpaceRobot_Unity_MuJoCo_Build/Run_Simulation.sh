#!/usr/bin/env bash
set -Eeuo pipefail
here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
graphics_args=()
if [[ -n "${DISPLAY:-}" ]] && command -v glxinfo >/dev/null 2>&1 && ! glxinfo -B >/dev/null 2>&1; then
  export __GLX_VENDOR_LIBRARY_NAME=mesa
  export LIBGL_ALWAYS_SOFTWARE=1
  graphics_args=(-force-glcore)
  echo 'Native OpenGL unavailable; using Mesa software rendering.'
fi
exec "$here/SpaceRobot_Service" "${graphics_args[@]}" "$@"
