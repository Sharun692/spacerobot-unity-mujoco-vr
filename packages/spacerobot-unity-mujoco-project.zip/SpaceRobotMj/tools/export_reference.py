"""Export the MuJoCo mission trace used by the Unity scene."""

import argparse
import gzip
import json
import math
import struct
from pathlib import Path

import mujoco
import numpy as np

from build_high_fidelity_model import build
from run_high_fidelity_service import (
    LEGS,
    MissionController,
    contact_measurements,
    initialize_model,
    joint_value,
)


FRAME_FIELDS = 20
SWIZZLE = np.array([[1, 0, 0], [0, 0, 1], [0, 1, 0]], dtype=float)
HERE = Path(__file__).resolve().parent
DATA = HERE.parent / "Assets" / "StreamingAssets"


def geometry(model):
    result = []
    for i in range(model.ngeom):
        name = mujoco.mj_id2name(model, mujoco.mjtObj.mjOBJ_GEOM, i) or f"geom_{i}"
        body = mujoco.mj_id2name(model, mujoco.mjtObj.mjOBJ_BODY, int(model.geom_bodyid[i])) or "world"
        result.append(
            {
                "name": name,
                "body": body,
                "type": int(model.geom_type[i]),
                "size": [float(x) for x in model.geom_size[i]],
                "rgba": [float(x) for x in model.geom_rgba[i]],
                "contact": bool(model.geom_contype[i] and model.geom_conaffinity[i]),
            }
        )
    return result


def pose_array(data):
    positions = data.geom_xpos @ SWIZZLE
    rotations = SWIZZLE @ data.geom_xmat.reshape(-1, 3, 3) @ SWIZZLE
    quaternions = np.empty((len(rotations), 4), dtype=np.float64)
    for i, rotation in enumerate(rotations):
        quaternion = np.empty(4, dtype=np.float64)
        mujoco.mju_mat2Quat(quaternion, rotation.reshape(9))
        quaternions[i] = (quaternion[1], quaternion[2], quaternion[3], quaternion[0])
    return np.concatenate((positions, quaternions), axis=1).astype("<f4").reshape(-1)


def export(duration):
    DATA.mkdir(parents=True, exist_ok=True)
    build()
    model = mujoco.MjModel.from_xml_path(str(HERE / "spacerobot_high_fidelity.xml"))
    data = mujoco.MjData(model)
    initialize_model(model, data)
    controller = MissionController(model, data)
    every = 50  # one frame per 50 physics steps, nominally 20 Hz
    frames = int(math.ceil(duration / (every * model.opt.timestep)))
    stages = []
    stage_lookup = {}
    metadata = {
        "source": "Sharun692/iss_top_robot_high_fidelity_v2",
        "model": "spacerobot_high_fidelity.xml",
        "physics_engine": f"MuJoCo {mujoco.__version__}",
        "physics_step_s": float(model.opt.timestep),
        "sample_step": every,
        "geom_count": model.ngeom,
        "frame_count": frames,
        "frame_fields": FRAME_FIELDS,
        "geoms": geometry(model),
    }
    path = DATA / "mission_frames.bin.gz"
    with gzip.open(path, "wb", compresslevel=5) as stream:
        stream.write(struct.pack("<4siii", b"SROB", model.ngeom, frames, FRAME_FIELDS))
        frame_index = 0
        step = 0
        while data.time < duration:
            contacts = contact_measurements(model, data)
            controller.update(data.time, contacts)
            mujoco.mj_step(model, data)
            if step % every == 0:
                post = contact_measurements(model, data)
                stage = controller.stage
                if stage not in stage_lookup:
                    stage_lookup[stage] = len(stages)
                    stages.append(stage)
                header = [
                    data.time,
                    stage_lookup[stage],
                    joint_value(model, data, "cap_hinge"),
                    post["cap_contact_force"],
                    sum(controller.rail_latched(leg) for leg in LEGS),
                    data.xpos[model.body("robot").id, 0],
                    len(post["cap_fingers"]["FR"]),
                    int(controller.cap_grasp_verified),
                ]
                header += [post["grip_forces"][leg] for leg in LEGS]
                header += [len(post["rail_fingers"][leg]) for leg in LEGS]
                header += [len(post["cap_fingers"][leg]) for leg in LEGS]
                assert len(header) == FRAME_FIELDS
                payload = np.concatenate((np.asarray(header, dtype="<f4"), pose_array(data)))
                stream.write(payload.tobytes())
                frame_index += 1
            step += 1
    if frame_index != frames:
        raise RuntimeError(f"Recorded {frame_index} frames; expected {frames}")
    metadata["stages"] = stages
    (DATA / "model_metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")
    print(f"Exported {frame_index} frames, {model.ngeom} geoms, {len(stages)} stages")
    print(f"Final cap angle: {joint_value(model, data, 'cap_hinge'):.5f} rad")
    print(f"Regrasp wait steps: {controller.regrasp_failures}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--duration", type=float, default=150.0)
    export(parser.parse_args().duration)
