"""Validate the recorded MuJoCo mission trace."""

import gzip
import json
import struct
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "Assets" / "StreamingAssets"
metadata = json.loads((DATA / "model_metadata.json").read_text())
with gzip.open(DATA / "mission_frames.bin.gz", "rb") as stream:
    magic, geoms, frames, fields = struct.unpack("<4siii", stream.read(16))
    raw = stream.read()
assert magic == b"SROB"
assert geoms == len(metadata["geoms"]) == 180
assert frames == metadata["frame_count"] == 3000
assert fields == metadata["frame_fields"] == 20
samples = np.frombuffer(raw, dtype="<f4").reshape(frames, fields + 7 * geoms)
times = samples[:, 0]
stages = [metadata["stages"][int(index)] for index in samples[:, 1]]
result = {
    "frames": frames,
    "geometries": geoms,
    "last_time_s": float(times[-1]),
    "final_stage": stages[-1],
    "final_cap_angle_rad": float(samples[-1, 2]),
    "minimum_active_rail_latches": int(samples[:, 4].min()),
    "maximum_cap_finger_contacts": int(samples[:, 17].max()),
    "maximum_cap_contact_force_N": float(samples[:, 3].max()),
}
assert np.all(np.diff(times) > 0)
assert np.all(np.isfinite(samples))
assert result["final_stage"] == "cap-task-complete"
assert abs(result["final_cap_angle_rad"] - 0.948165509) < 0.02
assert result["minimum_active_rail_latches"] >= 3
assert result["maximum_cap_finger_contacts"] >= 2
(ROOT / "reference_validation.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
